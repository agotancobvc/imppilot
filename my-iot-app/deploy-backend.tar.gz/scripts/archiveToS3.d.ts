import { DynamoDBStreamEvent, Context } from 'aws-lambda';
export declare const handler: (event: DynamoDBStreamEvent, _ctx: Context) => Promise<void>;
//# sourceMappingURL=archiveToS3.d.ts.map