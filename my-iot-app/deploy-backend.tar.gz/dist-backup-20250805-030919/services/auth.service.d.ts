export declare function signAccessToken(payload: object): never;
//# sourceMappingURL=auth.service.d.ts.map