declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=user.routes.d.ts.map