import { Express } from 'express';
export default function routes(app: Express): void;
//# sourceMappingURL=index.d.ts.map