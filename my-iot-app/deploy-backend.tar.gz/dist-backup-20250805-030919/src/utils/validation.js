export function parse(schema, data) {
    return schema.parse(data);
}
//# sourceMappingURL=validation.js.map