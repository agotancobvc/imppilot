export declare const toISO: (date: Date) => string;
export declare const toEpoch: (date: Date) => number;
//# sourceMappingURL=formatters.d.ts.map