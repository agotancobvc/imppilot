export const toISO = (date) => date.toISOString();
export const toEpoch = (date) => Math.floor(date.getTime() / 1_000);
//# sourceMappingURL=formatters.js.map