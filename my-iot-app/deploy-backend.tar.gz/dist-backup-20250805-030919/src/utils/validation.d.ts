import { ZodSchema } from 'zod';
export declare function parse<T>(schema: ZodSchema<T>, data: unknown): T;
//# sourceMappingURL=validation.d.ts.map