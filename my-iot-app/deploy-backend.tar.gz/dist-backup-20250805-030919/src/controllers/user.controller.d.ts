import { Request, Response } from 'express';
export declare function createPatient(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
export declare function updateClinicianProfile(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
export declare function createClinician(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
//# sourceMappingURL=user.controller.d.ts.map