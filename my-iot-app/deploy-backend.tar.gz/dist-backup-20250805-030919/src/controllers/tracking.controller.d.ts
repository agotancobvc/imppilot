import { Request, Response } from 'express';
export declare function getTrackingHistory(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
//# sourceMappingURL=tracking.controller.d.ts.map