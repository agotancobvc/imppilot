import { Request, Response } from 'express';
export declare function clinicLogin(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
export declare function clinicianLogin(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
export declare function patientLogin(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
export declare function refreshToken(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
//# sourceMappingURL=auth.controller.d.ts.map