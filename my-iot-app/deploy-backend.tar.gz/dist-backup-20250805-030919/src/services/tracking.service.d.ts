import { Server as SocketIOServer } from 'socket.io';
export declare function registerSocketHandlers(io: SocketIOServer): void;
//# sourceMappingURL=tracking.service.d.ts.map