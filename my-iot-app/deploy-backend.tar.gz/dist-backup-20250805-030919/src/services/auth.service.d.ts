export declare function signAccessToken(payload: object): any;
//# sourceMappingURL=auth.service.d.ts.map