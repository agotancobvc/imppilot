export declare function createClinic(data: any): Promise<{
    code: string;
    name: string;
    id: string;
    createdAt: Date;
}>;
//# sourceMappingURL=postgres.service.d.ts.map