export declare function getPatientById(patientId: string): Promise<{
    id: string;
    clinicId: string;
    firstName: string;
    lastName: string;
    mrn: string;
} | null>;
//# sourceMappingURL=user.service.d.ts.map