"use strict";
//# sourceMappingURL=clinic.model.js.map