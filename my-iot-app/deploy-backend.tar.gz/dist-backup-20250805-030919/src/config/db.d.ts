import { PrismaClient } from '@prisma/client';
export declare function getPrisma(): Promise<PrismaClient>;
//# sourceMappingURL=db.d.ts.map