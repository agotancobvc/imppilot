import { Request, Response, NextFunction } from 'express';
export declare function errorMiddleware(err: any, _req: Request, res: Response, _next: NextFunction): Response<any, Record<string, any>>;
//# sourceMappingURL=error.middleware.d.ts.map